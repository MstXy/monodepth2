from monodepth2.UPFlow_pytorch.kitti_2015_flow_test import kitti_2015_test
if __name__ == "__main__":
    kitti_2015_test()