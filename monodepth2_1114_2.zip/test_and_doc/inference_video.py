import time
from datetime import datetime
from PIL import Image
from tqdm import tqdm
import numpy as np
from tensorboardX import SummaryWriter
import flow_vis
import json
import math
import os
import sys
import pdb
file_dir = os.path.dirname(__file__)
parent_project = os.path.dirname(file_dir)
sys.path.append(os.path.dirname(parent_project))

# ==== torch import
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import torchvision.utils as tvu
import torchvision.transforms.functional as F



# ==== monodepth module import
import monodepth2.datasets as datasets
import monodepth2.utils.utils as mono_utils
from monodepth2.UPFlow_pytorch.utils.tools import tools as uptools
import monodepth2.networks as networks
from monodepth2.layers import *

from monodepth2.networks.MonoFlowNet import MonoFlowNet
from monodepth2.networks.UnFlowNet import UnFlowNet
from monodepth2.networks.ARFlow_models.pwclite import PWCLite
from monodepth2.networks.pwc_decoder_ori import PWCDecoder_from_img
from monodepth2.networks.ARFlow_models.pwclite_withResNet import PWCLiteWithResNet
from monodepth2.options import MonodepthOptions
options = MonodepthOptions()
opt = options.parse()

fpath = os.path.join(os.path.dirname(__file__), "splits", opt.split, "{}_files.txt")
import matplotlib.pyplot as plt
import matplotlib.colors as colors
cmap = plt.get_cmap('viridis')
import monodepth2.datasets.flow_eval_datasets as flow_eval_datasets
from monodepth2.utils import frame_utils
from monodepth2.utils.utils import InputPadder, forward_interpolate

from monodepth2.ARFlow_losses.flow_loss import unFlowLoss
import cv2
from easydict import EasyDict 

'''
cd ~/data16t/Projects/test0906/monodepth2/test_and_doc
ffmpeg -i flow_test.mp4 -r 2 -f image2 imgs_f2/%05d.png && python inference_video.py 
'''


def pil_loader(path):
    return Image.open(path).convert('RGB')

class Dict2Class(object):
    def __init__(self, my_dict):
        for key in my_dict:
            setattr(self, key, my_dict[key])

device = 'cuda:1'
model_save_path = '/home/liu/data16t/Projects/test0906/monodepth2/test_and_doc/monoFlow.pth'
model_save_path = '/home/liu/data16t/Projects/mono_log/2023-09-16_16-46-08/ARFlow/models/weights_113/monoFlow.pth' # difint dataset
file_list = os.listdir('imgs_f2')
file_list.sort()

# create video writer
output_file = 'out_video.mp4'
frame_width, frame_height = 640*3, 192*3
fps=30
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Codec for MP4
out_video_writer = cv2.VideoWriter(output_file, fourcc, fps, (frame_width, frame_height*2))


# model loading
with open('/home/liu/data16t/Projects/test0906/monodepth2/ARFlow_losses/kitti_raw.json') as f:
    cfg = EasyDict(json.load(f))
resize = transforms.Resize((frame_height, frame_width))
to_tensor = transforms.ToTensor()


model = PWCLite(cfg.model)
model.load_state_dict(torch.load(model_save_path, map_location=torch.device('cpu')))
model = model.to(device).eval()
flow_list = []

# creating image pairs for optical flow
for i in range(min(len(file_list)-1, 3000)):
    input_dict = {}
    img1 = resize(to_tensor(pil_loader('imgs_f2/'+file_list[i])).to(device).unsqueeze(0))
    img2 = resize(to_tensor(pil_loader('imgs_f2/'+file_list[i+1])).to(device).unsqueeze(0))
    input_dict[("color_aug", -1, 0)], input_dict[("color_aug", 0, 0)] = img1, img2
    out_dict = model(input_dict)
    flow_1_2 = out_dict['flow', -1, 0, 0][0]
    # flow_list.append(flow_1_2.cpu())
    cv2_image = np.array(
        mono_utils.stitching_and_show([flow_1_2.cpu(), img1[0].cpu()], ver=True, show=False)
        )
    
    cv2_image = cv2.cvtColor(cv2_image, cv2.COLOR_RGB2BGR)
    # cv2_image = cv2.resize(cv2_image, (frame_width, frame_height))
    out_video_writer.write(cv2_image)
    del input_dict
    del out_dict
    if i%100 == 0:
        print(i)

out_video_writer.release()