import torch
from torch.utils.data import dataloader, dataset
import torch.nn as nn
import time
# ==== torch ddp import
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed import init_process_group, destroy_process_group
import torch.multiprocessing as mp



class Mydataset(dataset):
    def __init__():
        pass
    
    def __getitem__(self, index):
        return torch.randn(10)
    
    def _len__(self):
        return 800

mydataset = Mydataset()   
train_dataloader = dataloader(
    train_dataset=mydataset,
    batch_size=10,
    num_workers=10,
    pin_memory=True,
    shuffle= False,
    sampler=(torch.utils.data.distributed.DistributedSampler(mydataset)),
    drop_last=True
)


class MyModel(nn.Module):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.li = nn.Linear(10, 100) 
    def forward(self, x):
        return self.li(x)
    
    
net = MyModel()
def train(self, ):
    start_t = time.time()
    for epoch in range(20):
        self.epoch = epoch
        self.train_loader.sampler.set_epoch(epoch)
        self._run_epoch()


def ddp_setup(rank, world_size):
    """
    Args:
        rank: Unique identifier of each process
        world_size: Total number of processes
    """
    os.environ["MASTER_ADDR"] = "localhost"
    os.environ["MASTER_PORT"] = "29500"
    dist.init_process_group(backend="nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)

def main(rank: int, world_size: int):
    ddp_setup(rank, world_size)

    trainer = MyModel(gpu_id=rank+4, train_dataset=train_dataset, train_loader=train_loader, val_dataset=val_dataset, val_loader=val_loader)
    trainer.train()
    destroy_process_group()


if __name__ == "__main__":
    if opt.ddp:
        import os
        os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID" # see issue #152
        os.environ["CUDA_VISIBLE_DEVICES"]="4, 5, 6, 7"
        opt.world_size = torch.cuda.device_count()
        mp.spawn(main, args=(opt.world_size,), nprocs=opt.world_size, join=True)
    else:
        train_dataset, train_loader = load_train_objs()
        val_dataset, val_loader = load_val_objs()
        trainer = DDP_Trainer(int(opt.device[-1]), train_dataset, train_loader,
                              val_dataset, val_loader)
        trainer.train()